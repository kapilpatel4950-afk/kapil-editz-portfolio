# Kapil.editz.01 — Portfolio (Vite + React)

This is a ready-to-deploy Vite + React project for Kapil's video editing portfolio.

## How to run locally

1. unzip
2. cd into project folder
3. npm install
4. npm run dev

## Deploy to Vercel

1. Push this repo to GitHub
2. Import the repo into Vercel (https://vercel.com/new)
3. Vercel will detect it as Vite/React and auto-deploy.

