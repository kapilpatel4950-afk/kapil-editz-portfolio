import React from 'react'
import { motion } from 'framer-motion'
import './styles.css'

export default function App(){
  const projects = [
    { id: 1, title: 'Project 1', thumb: '/images/project1.jpg', link: 'https://drive.google.com/file/d/11SWOJSF4xTKdPEI-pIBMdoup9eHhjuky/view?usp=drivesdk', tag: 'Edit' },
    { id: 2, title: 'Project 2', thumb: '/images/project2.jpg', link: 'https://drive.google.com/file/d/1tLTfUci8fiQcLm1S7xEKm-Vzq2LKvZdy/view?usp=drivesdk', tag: 'Edit' },
    { id: 3, title: 'Project 3', thumb: '/images/project3.jpg', link: 'https://drive.google.com/file/d/1oaDXBNqHwSbfaA-YoiBTR8JBT8xe53DL/view?usp=drivesdk', tag: 'Edit' },
    { id: 4, title: 'Project 4', thumb: '/images/project4.jpg', link: 'https://drive.google.com/file/d/1Y-2SRnVKg3yQROGwIzqA8VyUydnO5_dN/view?usp=drivesdk', tag: 'Edit' },
    { id: 5, title: 'Project 5', thumb: '/images/project5.jpg', link: 'https://drive.google.com/file/d/1o13NOq8aqGRmh_s5l8hHj9VVs8wHCJyu/view?usp=drivesdk', tag: 'Edit' },
    { id: 6, title: 'Project 6', thumb: '/images/project6.jpg', link: 'https://drive.google.com/file/d/1IldeMaUegnqgKBe5KSA9FTCc1ayhfrOn/view?usp=drivesdk', tag: 'Edit' },
  ]

  return (
    <div className="container">
      <header className="header">
        <div className="logo">
          <img src="/images/logo.png" alt="logo"/>
          <div>
            <div style={{fontWeight:700}}>Kapil.editz.01 — Video Editor</div>
            <div style={{fontSize:13,color:'#666'}}>Professional Video Editing • YouTube • Reels • Promos</div>
          </div>
        </div>
        <nav>
          <a href="#work" style={{marginRight:12}}>Work</a>
          <a href="#services" style={{marginRight:12}}>Services</a>
          <a href="#about" style={{marginRight:12}}>About</a>
          <a className="btn btn-primary" href="#contact">Contact</a>
        </nav>
      </header>

      <main>
        <section className="hero">
          <div className="left">
            <p style={{textTransform:'uppercase',color:'#666',fontSize:13}}>Professional Video Editing</p>
            <h1 style={{fontSize:36,margin:'8px 0'}}>I turn raw footage into engaging visual stories</h1>
            <p style={{color:'#444'}}>YouTube edits, short-form reels, travel films, promos — clean cuts, strong pacing, and color that pops.</p>
            <div style={{marginTop:16}}>
              <a className="btn btn-primary" href="#work" style={{marginRight:8}}>See Work</a>
              <a className="btn" href="#contact">Get Quote</a>
            </div>
            <ul style={{color:'#666',marginTop:12}}>
              <li>⚡ Fast turnaround</li>
              <li>🎯 Social-first editing</li>
              <li>🔁 Revisions until you're happy</li>
            </ul>
          </div>
          <div className="right">
            <motion.div className="card" initial={{opacity:0,scale:0.95}} animate={{opacity:1,scale:1}} transition={{duration:0.6}}>
              <img src="/images/hero-edit.jpg" alt="hero" style={{width:'100%',height:220,objectFit:'cover',borderRadius:8}}/>
            </motion.div>
          </div>
        </section>

        <section id="work" style={{marginTop:28}}>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
            <h3>Featured Work</h3>
          </div>
          <div className="grid">
            {projects.map(p=>(
              <a key={p.id} className="card project" href={p.link} target="_blank" rel="noreferrer" style={{textDecoration:'none',color:'inherit'}}>
                <img src={p.thumb} alt={p.title}/>
                <div style={{marginTop:8}}>
                  <div style={{fontSize:12,color:'#888'}}>{p.tag}</div>
                  <div style={{fontWeight:600}}>{p.title}</div>
                </div>
              </a>
            ))}
          </div>
        </section>

        <section id="services" style={{marginTop:30}}>
          <div className="card">
            <h3>Services</h3>
            <div className="grid" style={{marginTop:12}}>
              <div className="card">
                <h4>YouTube Editing</h4>
                <p>Full editing, pacing, thumbnails, chapters and export presets.</p>
              </div>
              <div className="card">
                <h4>Short-form Reels / TikTok</h4>
                <p>Vertical-first edits optimized for retention and engagement.</p>
              </div>
              <div className="card">
                <h4>Color Grading</h4>
                <p>Cinematic color grading for mood & consistency across episodes.</p>
              </div>
              <div className="card">
                <h4>Promo & Event Highlights</h4>
                <p>Fast-paced highlights and polished promotional videos.</p>
              </div>
            </div>
          </div>
        </section>

        <section id="about" style={{marginTop:30,display:'grid',gridTemplateColumns:'2fr 1fr',gap:16}}>
          <div className="card">
            <h3>About Kapil</h3>
            <p>Main Kapil.editz.01 hoon — ek creative video editor jo YouTube creators, brands aur social media clients ke liye high‑quality edits banata hoon. Main fast pacing, smooth transitions aur clean color workflows mein expert hoon. Mera focus hota hai engaging content banana jo dekhte hi viewer ko hook kare.</p>
            <ul style={{marginTop:12,color:'#666'}}>
              <li>• 5+ years editing experience</li>
              <li>• Clients: YouTubers, small brands, travel creators</li>
              <li>• Languages: Hindi, English</li>
            </ul>
          </div>

          <aside className="card">
            <h4>Contact</h4>
            <p style={{color:'#666'}}>Available for freelance & long-term collaboration.</p>
            <div style={{marginTop:12}}>
              <div>Email: <a href="mailto:kapillpatel4950@gamil.com">kapillpatel4950@gamil.com</a></div>
              <div style={{marginTop:8}}>Instagram: <a href="https://www.instagram.com/kapil.editz.01" target="_blank" rel="noreferrer">@kapil.editz.01</a></div>
              <div style={{marginTop:8}}>WhatsApp: 7879052932</div>
            </div>
          </aside>
        </section>

        <section id="contact" style={{marginTop:30}}>
          <div className="card">
            <h3>Get in touch</h3>
            <p style={{color:'#666'}}>Tell me about your project — estimated length, style reference, and deadline.</p>
            <form style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8,marginTop:12}}>
              <input placeholder="Your name" style={{padding:10,borderRadius:8,border:'1px solid #eee'}}/>
              <input placeholder="Your email" style={{padding:10,borderRadius:8,border:'1px solid #eee'}}/>
              <input placeholder="Project type (YouTube / Reels / Promo)" style={{gridColumn:'1 / -1',padding:10,borderRadius:8,border:'1px solid #eee'}}/>
              <textarea placeholder="Brief description, links, deadlines" rows="4" style={{gridColumn:'1 / -1',padding:10,borderRadius:8,border:'1px solid #eee'}}/>
              <button type="button" className="btn btn-primary" style={{gridColumn:'1 / -1'}}>Send message</button>
            </form>
          </div>
        </section>

        <footer className="footer">
          © {new Date().getFullYear()} Kapil.editz.01 — Video Editor • Built with passion
        </footer>
      </main>
    </div>
  )
}
